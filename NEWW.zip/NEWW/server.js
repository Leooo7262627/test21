const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// MySQL Connection using XAMPP
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // Default user for XAMPP MySQL
  password: '', // Leave this blank for XAMPP default configuration
  database: 'sign_in_call_center' // The name of your database created in phpMyAdmin
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to the database:', err);
    return;
  }
  console.log('Connected to the MySQL database via XAMPP.');
});

// Routes
app.post('/signup', (req, res) => {
  const { firstName, lastName, dateOfBirth, phoneNumber, email, password, sex, city, country } = req.body;
  
  const hashedPassword = password; // Replace with actual hash function
  
  const query = `INSERT INTO users (first_name, last_name, date_of_birth, phone_number, email, password, sex, city, country) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
  db.query(query, [firstName, lastName, dateOfBirth, phoneNumber, email, hashedPassword, sex, city, country], (err, result) => {
    if (err) {
      console.error('Error saving user data:', err);
      res.status(500).json({ error: 'Error saving user data' });
      return;
    }
    res.json({ message: 'User registered successfully', userId: result.insertId });
  });
});

// Start the Server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
