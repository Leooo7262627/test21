document.addEventListener("DOMContentLoaded", function () {
  // Responsive Navigation Menu
  const navbarToggleBtn = document.querySelector("[data-navbar-toggle-btn]");
  const navbar = document.querySelector("[data-navbar]");
  
  navbarToggleBtn.addEventListener("click", () => {
    navbar.classList.toggle("active");
  });

  // Smooth Scroll
  const navLinks = document.querySelectorAll(".nav-link");
  navLinks.forEach((link) => {
    link.addEventListener("click", (event) => {
      event.preventDefault();
      const targetId = link.getAttribute("href").substring(1);
      const targetElement = document.getElementById(targetId);
      targetElement.scrollIntoView({ behavior: "smooth" });
      
      // Close the navbar after clicking
      if (navbar.classList.contains("active")) {
        navbar.classList.remove("active");
      }
    });
  });

  // "Go to Top" Button
  const goTopButton = document.querySelector(".go-top");
  window.addEventListener("scroll", () => {
    if (window.scrollY > 300) {
      goTopButton.classList.add("active");
    } else {
      goTopButton.classList.remove("active");
    }
  });

  goTopButton.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  // Form Validation
  const contactForm = document.querySelector(".contact-form");
  contactForm.addEventListener("submit", (event) => {
    const name = contactForm.querySelector("input[name='name']");
    const email = contactForm.querySelector("input[name='email']");
    const message = contactForm.querySelector("textarea[name='message']");

    if (name.value.trim() === "" || email.value.trim() === "" || message.value.trim() === "") {
      event.preventDefault();
      alert("Please fill out all required fields.");
    } else if (!validateEmail(email.value)) {
      event.preventDefault();
      alert("Please enter a valid email address.");
    }
  });

  function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
});



/**
 * go to top
 */

const goTopBtn = document.querySelector("[data-go-top]");

window.addEventListener("scroll", function () {

  if (window.scrollY >= 800) {
    goTopBtn.classList.add("active");
  } else {
    goTopBtn.classList.remove("active");
  }

});